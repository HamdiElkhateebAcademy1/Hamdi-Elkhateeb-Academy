document.addEventListener("DOMContentLoaded",()=>{
 const modal=document.getElementById("modal"), content=document.getElementById("modal-content");
 const show=(title,body)=>{content.innerHTML=`<h2>${title}</h2>${body}`;modal.hidden=false};
 const close=()=>modal.hidden=true;
 document.querySelector("[data-close]").onclick=close;
 modal.addEventListener("click",e=>{if(e.target===modal)close()});
 const login=()=>show("Student Login",`<p>This interface is ready. Real login requires an account service and database.</p><div class="form"><input placeholder="Email"><input type="password" placeholder="Password"><button onclick="alert('Real login will be connected at the server stage')">Log In</button><button onclick="alert('Real account creation will be connected at the server stage')">Create New Account</button></div>`);
 document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>{
  const a=b.dataset.action;
  if(a==="login")login();
  if(a==="notifications")show("Notifications","Course, session, and subscription notifications will appear here.");
  if(a==="messages")show("Messages","The messaging section is ready to connect to student communications.");
  if(a==="book")show("Book Session","The booking button is ready. Once booking or payment is connected, it will take the student to the next step.");
  if(a==="watch")show("Paid Content","This content will open after the student subscription is verified.");
  if(a==="payment")show("Connect Online Payment","This area is ready to connect to the payment gateway you choose. Payment credentials are not stored in public site files.");
 }));
 document.querySelectorAll("[data-course]").forEach(b=>b.addEventListener("click",()=>{
   const name=b.dataset.course;
   show(name,`<p>The course page is ready for development: description, curriculum, videos, files, quizzes, progress, and certificate.</p><button class="form button" onclick="alert('The purchase page will open after accounts and payment are connected.')">Proceed to Purchase</button>`);
 }));
 const search=document.getElementById("search"), cards=[...document.querySelectorAll(".searchable")];
 search.addEventListener("input",()=>{const q=search.value.trim().toLowerCase();cards.forEach(c=>c.style.display=!q||c.dataset.name.includes(q)?"":"none")});
 document.querySelectorAll("[data-go]").forEach(a=>a.addEventListener("click",e=>{
   e.preventDefault(); const id=a.dataset.go;
   if(id==="login")return login();
   const el=document.getElementById(id); if(el)el.scrollIntoView({behavior:"smooth"});
   document.querySelectorAll("nav a").forEach(x=>x.classList.toggle("active",x.dataset.go===id));
 }));
});