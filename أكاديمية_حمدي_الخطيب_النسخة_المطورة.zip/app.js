document.addEventListener("DOMContentLoaded",()=>{
 const modal=document.getElementById("modal"), content=document.getElementById("modal-content");
 const show=(title,body)=>{content.innerHTML=`<h2>${title}</h2>${body}`;modal.hidden=false};
 const close=()=>modal.hidden=true;
 document.querySelector("[data-close]").onclick=close;
 modal.addEventListener("click",e=>{if(e.target===modal)close()});
 const login=()=>show("دخول الطالب",`<p>هذه الواجهة جاهزة، وربط تسجيل الدخول الحقيقي يحتاج خدمة حسابات وقاعدة بيانات.</p><div class="form"><input placeholder="البريد الإلكتروني"><input type="password" placeholder="كلمة المرور"><button onclick="alert('سيتم ربط الدخول الحقيقي في مرحلة الخادم')">تسجيل الدخول</button><button onclick="alert('سيتم ربط إنشاء الحساب الحقيقي في مرحلة الخادم')">إنشاء حساب جديد</button></div>`);
 document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>{
  const a=b.dataset.action;
  if(a==="login")login();
  if(a==="notifications")show("الإشعارات","ستظهر هنا إشعارات الدورات والمحاضرات والاشتراكات.");
  if(a==="messages")show("الرسائل","قسم الرسائل جاهز للربط بنظام التواصل مع الطلاب.");
  if(a==="book")show("حجز الدفعة","زر الحجز جاهز. عند إضافة نظام الحجز أو الدفع سيتم تحويل الطالب للخطوة التالية.");
  if(a==="watch")show("المحتوى المدفوع","هذا المحتوى سيُفتح للطالب بعد التحقق من اشتراكه.");
  if(a==="payment")show("ربط الدفع الإلكتروني","هذه النقطة مجهزة للربط ببوابة الدفع التي ستختارها أنت. لا نضع بيانات الدفع داخل ملفات الموقع.");
 }));
 document.querySelectorAll("[data-course]").forEach(b=>b.addEventListener("click",()=>{
   const name=b.dataset.course;
   show(name,`<p>صفحة الكورس جاهزة للتطوير: وصف، منهج، فيديوهات، ملفات، اختبارات، نسبة إنجاز وشهادة.</p><button class="form button" onclick="alert('بعد ربط الحسابات والدفع سيتم فتح صفحة الشراء')">الانتقال للشراء</button>`);
 }));
 const search=document.getElementById("search"), cards=[...document.querySelectorAll(".searchable")];
 search.addEventListener("input",()=>{const q=search.value.trim().toLowerCase();cards.forEach(c=>c.style.display=!q||c.dataset.name.includes(q)?"":"none")});
 document.querySelectorAll("[data-go]").forEach(a=>a.addEventListener("click",e=>{
   e.preventDefault(); const id=a.dataset.go;
   if(id==="login")return login();
   const el=document.getElementById(id); if(el)el.scrollIntoView({behavior:"smooth"});
   document.querySelectorAll("nav a").forEach(x=>x.classList.toggle("active",x.dataset.go===id));
 }));
});