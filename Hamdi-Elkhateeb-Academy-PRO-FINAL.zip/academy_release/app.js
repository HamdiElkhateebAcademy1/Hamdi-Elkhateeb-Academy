const courses=[
 {id:1,title:'exocad Fundamentals',desc:'ابدأ بأساسيات التصميم الرقمي بخطوات واضحة وعملية.',level:'مبتدئ',icon:'EXOCAD'},
 {id:2,title:'Advanced Dental Design',desc:'طوّر التشريح والـ contours والإطباق من خلال حالات عملية.',level:'متقدم',icon:'DESIGN'},
 {id:3,title:'Implant Prosthetics',desc:'خطط وصمّم حالات التركيبات على الزرعات باحتراف.',level:'احترافي',icon:'IMPLANT'},
 {id:4,title:'Excel من الصفر للاحتراف',desc:'تعلم Excel من الأساسيات حتى التطبيقات العملية.',level:'مبتدئ',icon:'EXCEL'},
 {id:5,title:'أساسيات التصميم الجرافيكي',desc:'مبادئ التصميم والألوان والأدوات الأساسية.',level:'متوسط',icon:'DESIGN'}
];
const live=[['الدفعة الثانية - Excel','السبت · 7:00 م - 9:00 م'],['الدفعة الأولى - Photoshop','الاثنين · 6:00 م - 8:00 م'],['جلسة تطبيق عملي','الأربعاء · 8:00 م - 9:30 م']];
const recordings=[['محاضرة 4 - Excel','تطبيقات عملية على الجداول والدوال'],['محاضرة 2 - Photoshop','أساسيات التعامل مع التصميم'],['محاضرة 1 - exocad','بداية مشروع تصميم رقمي']];
const files=[['ملف التدريب - Excel.pdf','ملف PDF للتمرين العملي'],['قالب مشروع التصميم.zip','ملفات مشروع للتطبيق'],['أسئلة المراجعة.pdf','أسئلة قبل الاختبار']];
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function toast(t){const x=$('#toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2400)}
function openModal(id){$('#'+id).classList.add('open')}; function closeModals(){$$('.modal').forEach(m=>m.classList.remove('open'))}
function courseCard(c){return `<article class="course"><div class="course-img"><span class="fake">${c.icon}</span></div><div class="course-body"><span class="badge">${c.level}</span><h3>${c.title}</h3><p>${c.desc}</p><div class="course-bottom"><small>متاح للطلاب</small><button class="primary course-open" data-id="${c.id}">عرض الدورة ←</button></div></div></article>`}
$('#featuredCourses').innerHTML=courses.slice(0,3).map(courseCard).join(''); $('#allCourses').innerHTML=courses.map(courseCard).join('');
$('#liveList').innerHTML=live.map(x=>`<div class="list-card"><div class="list-icon">◉</div><div><h3>${x[0]}</h3><p>${x[1]}</p></div><button class="book">احجز الآن</button></div>`).join('');
$('#recordList').innerHTML=recordings.map(x=>`<div class="list-card"><div class="list-icon">▶</div><div><h3>${x[0]}</h3><p>${x[1]}</p></div><button class="watch" data-title="${x[0]}">مشاهدة</button></div>`).join('');
$('#fileList').innerHTML=files.map(x=>`<div class="list-card"><div class="list-icon">□</div><div><h3>${x[0]}</h3><p>${x[1]}</p></div><button class="download">تحميل</button></div>`).join('');
function showPage(page){$$('.page').forEach(p=>p.classList.toggle('active',p.dataset.view===page));$$('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));window.scrollTo({top:0,behavior:'smooth'});$('#sidebar').classList.remove('open')}
$$('[data-page]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
$$('.tabs button').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
$('#mobileMenu').onclick=()=>$('#sidebar').classList.toggle('open');
$('#loginBtn').onclick=()=>openModal('loginModal');$('#sideLogin').onclick=()=>openModal('loginModal');$('#welcomeLogin').onclick=()=>openModal('loginModal');$('#accountLogin').onclick=()=>openModal('loginModal');
$$('[data-close]').forEach(b=>b.onclick=closeModals); $$('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModals()}));
function setUser(name,email){localStorage.setItem('academyUser',JSON.stringify({name,email}));renderUser()}
function renderUser(){const u=JSON.parse(localStorage.getItem('academyUser')||'null'); if(u){$('#sideName').textContent=u.name;$('#sideStatus').textContent='طالب مسجّل';$('#accountName').textContent=u.name;$('#accountEmail').textContent=u.email;$('#accountLogin').style.display='none';$('#logoutBtn').style.display='inline-block';$('#followBtn').textContent='✓ تتابع الأكاديمية'}else{$('#sideName').textContent='زائر';$('#sideStatus').textContent='سجّل الدخول للمتابعة';$('#accountName').textContent='زائر';$('#accountEmail').textContent='لم يتم تسجيل الدخول';$('#accountLogin').style.display='inline-block';$('#logoutBtn').style.display='none'}}
$('#doLogin').onclick=()=>{const email=$('#email').value.trim();const pass=$('#password').value.trim();if(!email||!pass){toast('اكتب البريد الإلكتروني وكلمة المرور');return}setUser(email.split('@')[0]||'طالب',email);closeModals();toast('تم تسجيل الدخول بنجاح');showPage('account')};
$('#demoLogin').onclick=()=>{setUser('طالب تجريبي','student@example.com');closeModals();toast('تم الدخول بالحساب التجريبي');showPage('home')};
$('#logoutBtn').onclick=()=>{localStorage.removeItem('academyUser');renderUser();toast('تم تسجيل الخروج')};
$('#followBtn').onclick=()=>{if(!localStorage.getItem('academyUser')){openModal('loginModal');toast('سجّل الدخول أولًا لمتابعة الأكاديمية')}else{localStorage.setItem('following','1');$('#followBtn').textContent='✓ تتابع الأكاديمية';toast('تمت متابعة الأكاديمية')}};
$('#moreBtn').onclick=()=>openModal('moreModal');$('#shareBtn').onclick=async()=>{try{await navigator.share({title:document.title,url:location.href});}catch(e){toast('يمكنك مشاركة رابط الصفحة من المتصفح')}};$('#copyBtn').onclick=async()=>{try{await navigator.clipboard.writeText(location.href);toast('تم نسخ الرابط')}catch(e){toast('انسخ الرابط من شريط المتصفح')}};$('#moreLang').onclick=()=>toggleLang();
$('#introBtn').onclick=()=>{toast('أكاديمية حمدي الخطيب — تعلّم عملي، تطبيق حقيقي، وتطوير مستمر');};
$$('.course-open').forEach(b=>b.onclick=()=>{const c=courses.find(x=>x.id==b.dataset.id);toast('تم فتح دورة: '+c.title);showPage('recordings')});
$$('.book').forEach(b=>b.onclick=()=>{if(!localStorage.getItem('academyUser'))openModal('loginModal');else toast('تم تسجيل طلب الحجز، وسيتم تأكيد الموعد من الإدارة')});
$$('.watch').forEach(b=>b.onclick=()=>{$('#videoTitle').textContent=b.dataset.title;openModal('videoModal')});
$$('.download').forEach(b=>b.onclick=()=>toast('سيتم تنزيل الملف بعد ربط ملفات التدريب الحقيقية بالمنصة'));
$$('.answers button').forEach(b=>b.onclick=()=>{if(b.dataset.answer==='yes'){toast('إجابة صحيحة ✓')}else toast('إجابة غير صحيحة — جرّب مرة أخرى')});
$('#certBtn').onclick=()=>{if(!localStorage.getItem('academyUser')){openModal('loginModal');return}toast('الشهادة تصبح متاحة بعد إكمال الدورة')};
let lang='ar'; function toggleLang(){lang=lang==='ar'?'en':'ar';if(lang==='en'){document.documentElement.lang='en';document.documentElement.dir='ltr';$('#langBtn').textContent='AR';toast('تم التبديل للإنجليزية')}else{document.documentElement.lang='ar';document.documentElement.dir='rtl';$('#langBtn').textContent='EN';toast('تم التبديل للعربية')}}$('#langBtn').onclick=toggleLang;
$('#searchInput').addEventListener('input',e=>{const q=e.target.value.toLowerCase();$$('.course').forEach(c=>c.style.display=c.textContent.toLowerCase().includes(q)?'':'none')});
renderUser();
</script>
